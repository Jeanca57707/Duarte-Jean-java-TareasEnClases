package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.*;
import java.util.*;

public class controller {

    @FXML
    private TextField longitudContrasenia;

    @FXML
    private CheckBox cbMayuscula;

    @FXML
    private CheckBox cbNumeros;

    @FXML
    private CheckBox cbSimbolos;

    @FXML
    private Button btGenerar;

    @FXML
    private Button btLimpiar;

    @FXML
    private Label lbContrasenia;

    @FXML 
    private Label mensaje;


    @FXML
    private void initialize(){

        longitudContrasenia.setPromptText("Digite la cantidad de dígitos de la contraseña");

        cbMayuscula.setText("Incluir mayúsculas");
        cbNumeros.setText("Incluir números");
        cbSimbolos.setText("Incluir símbolos");

        mensaje.setText("Esperando configuración");

    }

    @FXML
    private void generar(ActionEvent event){

        if(longitudContrasenia.getText() == null){
            mensaje.setText("No deje vacía la longitud");
            return;
        }

        int longitud = 0;

        try{

            longitud = Integer.parseInt(longitudContrasenia.getText());

        }catch(NumberFormatException e){

            mensaje.setText("Debe digitar un valor numérico");
            return;
        }

        if(longitud <= 5){

            mensaje.setText("La contraseña de contener al menos 6 dígitos");
            return;
        }

        Random random = new Random();
        String contrasenia = "";
        String caracteres = "abcdefghijklmnopqrstuvwxyz";
        

        if(cbMayuscula.isSelected()){

            caracteres += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";            
        }
        if(cbNumeros.isSelected()){

            caracteres += "0123456789";
        }
        if(cbSimbolos.isSelected()){
           
            caracteres += "!@#$%&*?";
        }
      

        for (int i = 0; i< longitud; i++){

            char digito = caracteres.charAt(random.nextInt(caracteres.length()));
            contrasenia += digito;
        }
        
        lbContrasenia.setText("Contraseña: " + contrasenia);

        mensaje.setText("Contraseña generada exitosamente!");


    }

    @FXML
    private void limpiar(ActionEvent event){

        longitudContrasenia.clear();

        cbMayuscula.setSelected(false);
        cbNumeros.setSelected(false);
        cbSimbolos.setSelected(false);

        lbContrasenia.setText("");
        mensaje.setText("Esperando configuración");
    }


    @FXML
    private void mouseEntrada(MouseEvent event){

        mensaje.setText("Presione para generar una nueva contraseña");
    }

    @FXML
    private void mouseSalida(MouseEvent event){

        mensaje.setText("Esperando configuración");
    }

    @FXML
    private void enter(KeyEvent event){

        if(event.getCode() == KeyCode.ENTER){

          generar(new ActionEvent());
        }
    }









    
}
