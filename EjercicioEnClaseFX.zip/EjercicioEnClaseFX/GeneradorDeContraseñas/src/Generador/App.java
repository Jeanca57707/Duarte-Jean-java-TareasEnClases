package Generador;

import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.fxml.FXMLLoader;

public class App extends Application {

    @Override
    public void start(Stage primarStage) throws Exception{

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/view.fxml"));

        Scene scene = new Scene(loader.load());
        scene.getStylesheets().add(getClass().getResource("/css/estilo.css").toExternalForm());


        primarStage.setTitle("Generador de contraseñas");
        primarStage.setScene(scene);
        primarStage.show();
    }

    public static void main(String[] args) throws Exception{

        launch(args);
    }
    
}
