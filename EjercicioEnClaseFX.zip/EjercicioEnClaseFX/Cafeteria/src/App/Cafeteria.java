package App;

import javafx.application.*;
import javafx.scene.*;
import javafx.stage.*;
import javafx.fxml.FXMLLoader;

public class Cafeteria extends Application{

    @Override
    public void start(Stage primarStage)throws Exception{


        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/view.fxml"));

        Scene scene = new Scene(loader.load());
        scene.getStylesheets().add(getClass().getResource("/css/estilo.css").toExternalForm());

        primarStage.setTitle("Cafeteria");
        primarStage.setScene(scene);
        primarStage.show();

    }
    public static void main(String[] args) throws Exception{

    launch(args);
    }


}

