package Controller;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

public class controller{


    @FXML
    private TextField nombreCliente;

    @FXML
    private ComboBox<String> cbBebidas;

    @FXML
    private TextField cantidad;

    @FXML
    private CheckBox cbPostre;

    @FXML
    private Button btCalcular;

    @FXML
    private Button btLimpiar;

    @FXML
    private Label compra;

    @FXML
    private Label total;

    @FXML
    private Label mensaje;



    @FXML
    public void initialize(){


        cbBebidas.setItems(FXCollections.observableArrayList("Cafe americano | RD$100", "Cappuccino | RD$150", 
        "Chocolate caliente | RD$130", "Jugo natural | RD$120"));

        cbBebidas.setPromptText("Seleccione una bebida...");

        cbPostre.setText("Si");

        mensaje.setText("Esperando datos de la compra");

    }

    @FXML

    private void calcular(ActionEvent event){
 
        if(nombreCliente.getText().isEmpty() || cbBebidas.getValue().isEmpty()
        || cantidad.getText().isEmpty() || cantidad.getText().isEmpty()){

            mensaje.setText("No puede quedar un campo vacío");
            return;
        }

        int cantidadBebidas;
        
        try{

            cantidadBebidas = Integer.parseInt(cantidad.getText());

        }catch(NumberFormatException e){

            mensaje.setText("La cantidad debe ser numérica");
            return;
        }

        if(cantidadBebidas <= 0){

            mensaje.setText("La cantidad debe ser mayor que 0");
            return;
        }

        double monto = 0;
        double subMonto = 0;
        String postre;

        if(cbBebidas.getValue().equals("Cafe americano | RD$100")){

            subMonto += (cantidadBebidas * 100);
            
        }
        else if(cbBebidas.getValue().equals("Cappuccino | RD$150")){

            subMonto += (cantidadBebidas * 150);
        }
         else if(cbBebidas.getValue().equals("Chocolate caliente | RD$130")){

            subMonto += (cantidadBebidas * 130);
        }
         else{

            subMonto += (cantidadBebidas * 120);
        }

        if(cbPostre.isSelected()){

            monto += 75;
            postre ="Si";
        }
        else{

            postre = "No";
        }
    
        monto += subMonto;

        compra.setText(

        "Cliente: " + nombreCliente.getText() +   
        "\nBebida: " + cbBebidas.getValue().split("\\|")[0].trim() + 
        "\nCantidad: " + cantidadBebidas +  
        "\nSubtotal = RD$" + subMonto +
        "\nPostre: " + postre
         
        );

        total.setText("El costo total es de: RD$" + monto);
    }

    @FXML
    private void limpiar(ActionEvent event){

        nombreCliente.clear();
        cantidad.clear();
        cbBebidas.getSelectionModel().clearSelection();
        cbPostre.setSelected(false);
        compra.setText("");
        total.setText("");
        mensaje.setText("Esperando datos de la compra...");
    }

    @FXML
    private void mouseEntrada(MouseEvent event){

        mensaje.setText("Presione para calcular el monto total");

    }

    @FXML
    private void mouseSalida(MouseEvent event){

        mensaje.setText("Esperando información de la compra");
    }

    @FXML
    private void enter(KeyEvent event){

        if(event.getCode() == KeyCode.ENTER){

            calcular(new ActionEvent());
        }
    }
    
}
